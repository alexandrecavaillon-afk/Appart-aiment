# Meublés Vieux-Port

Appartements meublés, hors colocation, autour du Vieux-Port et de la Canebière (Marseille), relevés le 28 septembre 2026 sur Leboncoin, SeLoger et Bien'ici.

Page statique : photos, carte zoomable, commerces de proximité, itinéraires à pied, filtres par type, distance, état de rénovation et favoris.

## Mise en ligne avec GitHub Pages

1. Crée un dépôt et envoie tout le contenu de ce dossier à la racine (`index.html`, `graph.json`, `img/`, `.nojekyll`).
2. Dans le dépôt : **Settings → Pages → Build and deployment**, source **Deploy from a branch**, branche `main`, dossier `/ (root)`.
3. Le site est publié à l'adresse `https://<ton-compte>.github.io/<nom-du-depot>/`.

Ouvrir `index.html` directement depuis le disque fonctionne, sauf le calcul d'itinéraire (le navigateur bloque la lecture de `graph.json` en `file://`). Pour tester en local : `python3 -m http.server` dans ce dossier, puis http://localhost:8000.

## Sources et droits

- Fond de carte, réseau de rues et commerces : © contributeurs OpenStreetMap, licence ODbL.
- Photos et descriptions : issues des annonces, elles appartiennent à leurs auteurs (agences et particuliers). Garde ce site pour un usage personnel.
